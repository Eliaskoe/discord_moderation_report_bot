import json
import os
from utils.logger import setup_logger

logger = setup_logger()

def load_config():
    """Load configuration from config file"""
    try:
        config_path = os.path.join('config', 'config.json')
        if not os.path.exists(config_path):
            # Create default config if it doesn't exist
            default_config = {
                "prefix": "!",
                "log_channel_id": None,
                "mod_role_id": None,
                "report_channel_id": None
            }
            with open(config_path, 'w') as f:
                json.dump(default_config, f, indent=4)
            return default_config

        with open(config_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load config: {e}")
        return {"prefix": "!", "log_channel_id": None, "mod_role_id": None, "report_channel_id": None}
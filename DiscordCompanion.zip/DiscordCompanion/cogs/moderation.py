import discord
from discord.ext import commands
from discord import app_commands
import json
from utils.config_loader import load_config
from utils.logger import setup_logger
from collections import defaultdict
from typing import Dict, Tuple
import time

logger = setup_logger()

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = load_config()
        self.blacklist = self.load_blacklist()
        self.deleted_messages = {}  # Track bot-deleted messages

    def load_blacklist(self):
        try:
            with open('config/blacklist.json', 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load blacklist: {e}")
            return {"words": []}

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        # Don't log bot messages or filtered messages
        if message.author.bot or message.id in self.deleted_messages:
            return

        # Don't log command messages
        if message.content.startswith('/'):
            return

        # Log deleted message to logging channel if configured
        if self.config['log_channel_id']:
            try:
                log_channel = self.bot.get_channel(self.config['log_channel_id'])
                if log_channel:
                    embed = discord.Embed(
                        title="🗑️ Nachricht gelöscht",
                        color=discord.Color.orange(),
                        timestamp=discord.utils.utcnow()
                    )

                    # Author info
                    embed.add_field(
                        name="👤 Author",
                        value=f"**Name:** {message.author.name}\n**ID:** {message.author.id}",
                        inline=True
                    )

                    # Channel info
                    embed.add_field(
                        name="📍 Channel",
                        value=message.channel.mention,
                        inline=True
                    )

                    # Message content
                    if message.content:
                        embed.add_field(
                            name="📄 Nachricht",
                            value=f"```{message.content}```",
                            inline=False
                        )

                    # Add timestamp when message was created
                    if hasattr(message, 'created_at'):
                        embed.add_field(
                            name="⏰ Erstellt",
                            value=f"<t:{int(message.created_at.timestamp())}:R>",
                            inline=False
                        )

                    await log_channel.send(embed=embed)
                    logger.info(f"Sent delete log for message from {message.author.name}")

            except Exception as e:
                logger.error(f"Log Error: {e}")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        # Check for blacklisted words
        content_lower = message.content.lower()
        found_words = [word for word in self.blacklist["words"]
                      if word.lower() in content_lower]

        if found_words:
            try:
                # Track this message as bot-deleted
                self.deleted_messages[message.id] = True

                # Delete the message
                await message.delete()

                # Send warning DM to user
                warning_embed = discord.Embed(
                    title="⚠️ Achtung",
                    description="Deine Message wurde gelöscht, da verbotene Wörter enthalten waren.",
                    color=discord.Color.red()
                )
                warning_embed.add_field(
                    name="❓ Warum?",
                    value="Deine Nachricht enthielt verbotene Wörter",
                    inline=False
                )
                warning_embed.add_field(
                    name="📝 Deine Nachricht",
                    value=f"```{message.content}```",
                    inline=False
                )
                warning_embed.set_footer(text="Bei Fragen wende dich an einen Moderator")
                try:
                    await message.author.send(embed=warning_embed)
                except discord.errors.Forbidden:
                    logger.warning(f"Could not send DM to {message.author}")

                # Log to channel if configured
                if self.config['log_channel_id']:
                    log_channel = self.bot.get_channel(self.config['log_channel_id'])
                    if log_channel:
                        log_embed = discord.Embed(
                            title="🚫 Nachricht gelöscht (Wortfilter)",
                            color=discord.Color.red(),
                            timestamp=discord.utils.utcnow()
                        )
                        log_embed.add_field(
                            name="👤 Author",
                            value=f"**Name:** {message.author.name}\n**ID:** {message.author.id}",
                            inline=True
                        )
                        log_embed.add_field(
                            name="📍 Channel",
                            value=message.channel.mention,
                            inline=True
                        )
                        log_embed.add_field(
                            name="⚙️ Deleter",
                            value=f"**Name:** {self.bot.user.name}\n**ID:** {self.bot.user.id}",
                            inline=True
                        )
                        log_embed.add_field(
                            name="📝 Nachricht",
                            value=f"```{message.content}```",
                            inline=False
                        )
                        log_embed.add_field(
                            name="🚫 Gefundene Wörter",
                            value=", ".join(found_words),
                            inline=False
                        )
                        await log_channel.send(embed=log_embed)

            except discord.errors.Forbidden:
                logger.warning(f"Keine Rechte: {message.guild.name}")

    @app_commands.command(name="blacklist")
    @app_commands.describe(
        action="Wähle eine Aktion",
        word="Wort eingeben"
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="📝 Hinzufügen", value="add"),
        app_commands.Choice(name="❌ Entfernen", value="remove"),
        app_commands.Choice(name="📋 Liste", value="list")
    ])
    @app_commands.default_permissions(administrator=True)
    async def blacklist(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        word: str = None
    ):
        """Wortfilter verwalten"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Keine Rechte", ephemeral=True)
            return

        action = action.value
        if action == "list":
            words = ", ".join(self.blacklist["words"]) or "Keine Wörter"
            embed = discord.Embed(
                title="📋 Wortfilter",
                description=words,
                color=discord.Color.blue()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not word:
            await interaction.response.send_message("❌ Kein Wort angegeben", ephemeral=True)
            return

        if action == "add":
            if word.lower() not in [w.lower() for w in self.blacklist["words"]]:
                self.blacklist["words"].append(word.lower())
                message = f"✅ Hinzugefügt: {word}"
            else:
                message = f"ℹ️ Schon vorhanden: {word}"
        elif action == "remove":
            word_lower = word.lower()
            original_word = next((w for w in self.blacklist["words"] if w.lower() == word_lower), None)
            if original_word:
                self.blacklist["words"].remove(original_word)
                message = f"✅ Entfernt: {original_word}"
            else:
                message = f"ℹ️ Nicht gefunden: {word}"

        try:
            with open('config/blacklist.json', 'w') as f:
                json.dump(self.blacklist, f, indent=4)
            await interaction.response.send_message(message, ephemeral=True)
        except Exception as e:
            logger.error(f"Error: {e}")
            await interaction.response.send_message("❌ Fehler", ephemeral=True)

    @app_commands.command(name="setlogchannel")
    @app_commands.describe(
        channel="Channel für Logs"
    )
    @app_commands.default_permissions(administrator=True)
    async def setlogchannel(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):
        """Log Channel setzen"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Keine Rechte", ephemeral=True)
            return

        try:
            self.config['log_channel_id'] = channel.id
            with open('config/config.json', 'w') as f:
                json.dump(self.config, f, indent=4)
            await interaction.response.send_message(f"✅ Logs: {channel.mention}", ephemeral=True)
        except Exception as e:
            logger.error(f"Error: {e}")
            await interaction.response.send_message("❌ Fehler", ephemeral=True)

    @app_commands.command(name="setreportchannel")
    @app_commands.describe(
        channel="Channel für Reports"
    )
    @app_commands.default_permissions(administrator=True)
    async def setreportchannel(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):
        """Report Channel setzen"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Keine Rechte", ephemeral=True)
            return

        try:
            self.config['report_channel_id'] = channel.id
            with open('config/config.json', 'w') as f:
                json.dump(self.config, f, indent=4)
            await interaction.response.send_message(f"✅ Reports: {channel.mention}", ephemeral=True)
        except Exception as e:
            logger.error(f"Error: {e}")
            await interaction.response.send_message("❌ Fehler", ephemeral=True)

    @app_commands.command(name="members")
    @app_commands.default_permissions(administrator=True)
    async def members(
        self,
        interaction: discord.Interaction
    ):
        """Zeigt Anzahl der Member"""
        try:
            total_members = len(interaction.guild.members)
            await interaction.response.send_message(f"👥 {total_members} Member", ephemeral=False)
        except Exception as e:
            logger.error(f"Error: {e}")
            await interaction.response.send_message("❌ Fehler", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
import discord
from discord.ext import commands
from discord import app_commands
from utils.logger import setup_logger

logger = setup_logger()

class MessageCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="message",
        description="Sendet eine formatierte Nachricht"
    )
    @app_commands.describe(
        header="Header der Nachricht",
        title="Titel der Nachricht",
        nachricht="Deine Hauptnachricht",
        footer="Footer der Nachricht",
        author="Author der Nachricht"
    )
    async def message(
        self,
        interaction: discord.Interaction,
        header: str = None,
        title: str = None,
        nachricht: str = None,
        footer: str = None,
        author: str = None
    ):
        """Create and send a formatted message"""
        try:
            # Create embed
            embed = discord.Embed(color=discord.Color.blue())

            if header:
                embed.title = header
            if title:
                embed.add_field(name=title, value=nachricht or "­", inline=False)
            elif nachricht:
                embed.description = nachricht
            if footer:
                embed.set_footer(text=footer)
            if author:
                embed.set_author(name=author)

            await interaction.response.send_message(embed=embed)
            logger.info(f"Custom message sent by {interaction.user} in {interaction.channel}")

        except Exception as e:
            logger.error(f"Error creating custom message: {e}")
            await interaction.response.send_message("Ein Fehler ist aufgetreten", ephemeral=True)

    @app_commands.command(
        name="botinfo",
        description="Zeigt eine komplette Übersicht aller Bot Features"
    )
    @app_commands.default_permissions(administrator=True)
    async def botinfo(self, interaction: discord.Interaction):
        """Zeigt alle Bot Features"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Dieser Command ist nur für Administratoren", ephemeral=True)
            return

        try:
            embed = discord.Embed(
                title="🤖 Bot Features Übersicht",
                description="Eine übersichtliche Zusammenfassung aller Funktionen",
                color=discord.Color.blue()
            )

            # User Commands
            embed.add_field(
                name="👥 User Commands",
                value=(
                    "• `/help` - Zeigt verfügbare Commands\n"
                    "• `/report` - Meldet einen User"
                ),
                inline=False
            )

            # Admin Commands
            embed.add_field(
                name="⚡ Admin Commands",
                value=(
                    "• `/message` - Sendet formatierte Nachricht\n"
                    "• `/blacklist` - Verwaltet Wortfilter\n"
                    "• `/setlogchannel` - Setzt Log Channel\n"
                    "• `/setreportchannel` - Setzt Report Channel\n"
                    "• `/members` - Zeigt Memberanzahl\n"
                    "• `/botinfo` - Diese Übersicht"
                ),
                inline=False
            )

            # Report System
            embed.add_field(
                name="📢 Report System",
                value=(
                    "1️⃣ **Report erstellen**\n"
                    "→ User wählt Ziel und Grund\n"
                    "→ Bestätigung per DM\n\n"
                    "2️⃣ **Mod Aktionen**\n"
                    "→ ✅ Annehmen + DM\n"
                    "→ ❌ Ablehnen + DM\n"
                    "→ ➖ Ignorieren"
                ),
                inline=False
            )

            # Log System
            embed.add_field(
                name="📋 Log System",
                value=(
                    "1️⃣ **Gelöschte Nachrichten**\n"
                    "→ 👤 Author (Name & ID)\n"
                    "→ 📍 Channel\n"
                    "→ ⚙️ Deleter (Name & ID)\n"
                    "→ 📄 Nachrichteninhalt\n\n"
                    "2️⃣ **Wortfilter**\n"
                    "→ DM an User\n"
                    "→ Log im Mod-Channel"
                ),
                inline=False
            )

            embed.set_footer(text="Made by Elias")
            embed.timestamp = discord.utils.utcnow()

            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Botinfo angezeigt von {interaction.user}")

        except Exception as e:
            logger.error(f"Error showing botinfo: {e}")
            await interaction.response.send_message("❌ Ein Fehler ist aufgetreten", ephemeral=True)

async def setup(bot):
    await bot.add_cog(MessageCommands(bot))
import discord
from discord.ext import commands
from discord import app_commands
from utils.logger import setup_logger
from utils.config_loader import load_config

logger = setup_logger()

class ModeratorResponseModal(discord.ui.Modal, title="Message"):
    def __init__(self, reporter_id: int, action: str):
        super().__init__()
        self.reporter_id = reporter_id
        self.action = action

    nachricht = discord.ui.TextInput(
        label="Schreib was für den User",
        placeholder="Deine Nachricht...",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=1000
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            reporter = interaction.guild.get_member(self.reporter_id)
            if reporter:
                # Create embedded DM for reporter
                embed = discord.Embed(
                    color=discord.Color.green() if self.action == "accept" else discord.Color.red()
                )

                # Set title based on action
                embed.title = "✅ Report angenommen" if self.action == "accept" else "❌ Report abgelehnt"

                # Add moderator info
                embed.set_author(name=f"Moderator: {interaction.user.name}")

                # Add message
                embed.description = self.nachricht.value

                # Add timestamp
                embed.timestamp = discord.utils.utcnow()

                # Send DM with embed
                await reporter.send(embed=embed)

                # Delete report message and confirm to mod
                await interaction.message.delete()
                await interaction.response.send_message(
                    f"{'✅' if self.action == 'accept' else '❌'} DM wurde an {reporter.name} gesendet",
                    ephemeral=True
                )

        except Exception as e:
            logger.error(f"DM Error: {e}")
            await interaction.response.send_message("❌ DM konnte nicht gesendet werden", ephemeral=True)

class ReportButtons(discord.ui.View):
    def __init__(self, reporter_id: int):
        super().__init__(timeout=None)
        self.reporter_id = reporter_id

    @discord.ui.button(label="✅ Erledigt", style=discord.ButtonStyle.green)
    async def done_button(self, button_interaction: discord.Interaction, button: discord.ui.Button):
        try:
            modal = ModeratorResponseModal(self.reporter_id, "accept")
            await button_interaction.response.send_modal(modal)
        except Exception as e:
            logger.error(f"Error handling report: {e}")
            await button_interaction.response.send_message("❌ Fehler", ephemeral=True)

    @discord.ui.button(label="❌ Abgelehnt", style=discord.ButtonStyle.red)
    async def reject_button(self, button_interaction: discord.Interaction, button: discord.ui.Button):
        try:
            modal = ModeratorResponseModal(self.reporter_id, "reject")
            await button_interaction.response.send_modal(modal)
        except Exception as e:
            logger.error(f"Error handling report: {e}")
            await button_interaction.response.send_message("❌ Fehler", ephemeral=True)

    @discord.ui.button(label="➖ Ignorieren", style=discord.ButtonStyle.gray)
    async def ignore_button(self, button_interaction: discord.Interaction, button: discord.ui.Button):
        await button_interaction.message.delete()
        await button_interaction.response.send_message("➖ Ignoriert", ephemeral=True)

class ReportModal(discord.ui.Modal, title="Report"):
    def __init__(self, reported_user: discord.Member):
        super().__init__()
        self.reported_user = reported_user
        self.config = load_config()

    grund = discord.ui.TextInput(
        label="Was ist passiert?",
        placeholder="z.B. Spam, Beleidigung...",
        style=discord.TextStyle.short,
        required=True,
        max_length=100
    )

    details = discord.ui.TextInput(
        label="Mehr Details",
        placeholder="Erzähl was genau los war...",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=1000
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            embed = discord.Embed(
                title="📝 Neuer Report",
                color=discord.Color.yellow()
            )

            # Add reported user info with more details
            embed.add_field(
                name="👤 Reported User",
                value=f"**Name:** {self.reported_user.name}\n**ID:** {self.reported_user.id}\n**Joined:** <t:{int(self.reported_user.joined_at.timestamp())}:R>",
                inline=True
            )

            # Add reporter info
            embed.add_field(
                name="📢 Reporter",
                value=f"**Name:** {interaction.user.name}\n**ID:** {interaction.user.id}",
                inline=True
            )

            # Add report reason and details
            embed.add_field(
                name="⚠️ Grund",
                value=self.grund.value,
                inline=False
            )
            embed.add_field(
                name="📋 Details",
                value=self.details.value,
                inline=False
            )

            # Add timestamp
            embed.timestamp = discord.utils.utcnow()

            if self.config['report_channel_id']:
                report_channel = interaction.client.get_channel(self.config['report_channel_id'])
                if report_channel:
                    await report_channel.send(
                        embed=embed,
                        view=ReportButtons(reporter_id=interaction.user.id)
                    )

                    # Send confirmation DM to reporter
                    try:
                        confirm_embed = discord.Embed(
                            title="📬 Report eingereicht!",
                            description="Ein Moderator wird sich um deinen Report kümmern.",
                            color=discord.Color.blue()
                        )
                        confirm_embed.add_field(
                            name="🎯 Reported User",
                            value=self.reported_user.name,
                            inline=True
                        )
                        confirm_embed.add_field(
                            name="📝 Grund",
                            value=self.grund.value,
                            inline=True
                        )
                        await interaction.user.send(embed=confirm_embed)
                    except:
                        logger.error("Could not send DM to reporter")

                    await interaction.response.send_message("✅ Report wurde gesendet", ephemeral=True)
                else:
                    await interaction.response.send_message("❌ Kein Channel gefunden", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Kein Channel eingestellt", ephemeral=True)

        except Exception as e:
            logger.error(f"Error: {e}")
            await interaction.response.send_message("❌ Das hat nicht geklappt", ephemeral=True)

class UserSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(
            placeholder="Such nach einem User...",
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        selected_user = self.values[0]
        await interaction.response.send_modal(ReportModal(selected_user))

class ReportView(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.add_item(UserSelect())

class HelpCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="report")
    async def report_command(self, interaction: discord.Interaction):
        """User reporten"""
        embed = discord.Embed(
            title="⚠️ User reporten",
            description="Such dir einen User aus:",
            color=discord.Color.yellow()
        )

        await interaction.response.send_message(
            embed=embed,
            view=ReportView(),
            ephemeral=True
        )

    @app_commands.command(name="help")
    async def help_command(self, interaction: discord.Interaction):
        """Zeigt dir alle Commands"""
        embed = discord.Embed(
            title="📋 Deine Commands",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="Was du machen kannst",
            value=(
                "🔹 `/help` - Zeigt dir diese Liste\n"
                "🔹 `/report` - Melde einen User"
            ),
            inline=False
        )

        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(HelpCommands(bot))